CraftScripts are script files for WorldEdit that let you write world
editing scripts with JavaScript easily.

Example usage:
/cs maze.js lightstone 10 10

You may or may not install these scripts -- it is optional. If you are, however,
place the entire craftscripts/ folder into the respective directory for the platform
that you have installed WorldEdit for
(see http://wiki.sk89q.com/wiki/WorldEdit/Installation).

In order to be able to use CraftScripts, you must install the Rhino JavaScript library.
The installation page linked above has information about that. More information
about scripts in general can be found at
http://wiki.sk89q.com/wiki/WorldEdit/Scripting